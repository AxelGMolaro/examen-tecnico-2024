import { Injectable } from '@angular/core';
import { IProduct } from '../../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  products: IProduct[] = [
    {
      id: 1,
      name: "Producto 1 "
    },
    {
      id: 2,
      name: "Producto 2 "
    },
    {
      id: 3,
      name: "Producto 3 "
    },
  ]
    
  constructor() { }

  //mock get
  get(){
    return this.products;
  }
}
