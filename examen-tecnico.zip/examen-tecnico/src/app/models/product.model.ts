export interface IProduct{
    id: number;
    name: string;
}

export type ICreateProduct = Omit<IProduct, "id">;


