import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../core/services/product.service';
import { IProduct } from '../../models/product.model';
import { ListProductComponent } from './components/list-product/list-product.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [ListProductComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent  implements OnInit{

  products: IProduct[] = [];

  constructor(private _productService: ProductService){

  }

  ngOnInit(): void {

      this.products = this._productService.get();
      console.log(this.products)
  }



}
