import { Component, Input } from '@angular/core';
import { MatHeaderRowDef, MatTable,MatRowDef, MatTableModule } from '@angular/material/table';
import { IProduct } from '../../../../models/product.model';

@Component({
  selector: 'app-list-product',
  standalone: true,
    
    imports: [MatTableModule],
  templateUrl: './list-product.component.html',
  styleUrl: './list-product.component.css'
})
export class ListProductComponent {

  @Input() products:IProduct[] = [];

  displayedColumns: string[] = ['id', 'name'];

}
